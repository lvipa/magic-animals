Magic Animals / Milo and friends
8 illustrated character turnaround sheets. Modeling references, not rigged 3D assets.
Created with built-in ImageGen on 2026-10-01.
Use original full PNGs as Blender references. Resolve view inconsistencies before meshing.
See templates-manifest.json for names/species and prompts-v1.json for generation prompts.
